let
  inp = document.querySelector(".fib"),
  sab = document.querySelector(".sab"),
  som = document.querySelector(".som"),
  boi = document.querySelector(".inni");


function firstver() {
  var v = inp.value
  var l = v.length
  if(l < 8) {
    if(l == 7) sab.classList.add("main")
    else sab.classList.remove("main")
  } else {
    inp.value = v.slice(0, 7)
  }
}

function secover() {
  var v = inp.value
  var l = v.length
  // v = v.slice(0, 7)
  const cond = _=> (l == 7)
  
  somfun(cond())
  if(cond()) backResult(isNumberAvaible(v), v)
}

function somfun(bool) {
  if(bool) {
    som.classList.add("active")
    boi.style.setProperty("visibility", "hidden")
  }
  else { 
    som.classList.remove("active")
    boi.style.setProperty("visibility", "visible")
  }
}

inp.addEventListener("keyup", firstver)
sab.addEventListener("click", secover)


// space
function isNumberAvaible(Numb) {
  // Coming soon .. special algorithms
  // This is beta code
  // var ran = Math.floor(Math.random() * 10e6)
  var ran = Math.floor(Math.random() *10)
  return ran > 5
}

function backResult(res, num) {
  if(res) {
    localStorage.MyNumber = num
    setTimeout(_=> {
      som.style.setProperty("display", "none")
      document.querySelector(".nono").style.setProperty("visibility", "hidden")
      
      var done = document.createElement("div")
      done.classList.add("rc", "go", "big", "col")
      done.innerHTML = `تم حجز الرقم: ${num} <br> <a onclick="Move('/')" class="rc btn main center">الصفحة الرئيسية</a>`
      document.body.appendChild(done)
    }, 2000)
  } else {
    cDesgin.CLC.toast("الرقم محجوز من قبل، اختر رقما اخر", "warn")
    inp.value = ""
    firstver()
    somfun(false)
  }
}


function rannum() {
  inp.value = Math.floor(Math.random() * 10e6)
  firstver()
}