const ind = {
  setup: function() {
    setInterval(function() {
      document.querySelector(".privatenum").innerHTML = `91${Math.floor(Math.random() * 10e6)}`
      cDesgin.CLC.write(document.querySelector(".privatenum"))
    }, 8000)
  }
}

ind.setup()