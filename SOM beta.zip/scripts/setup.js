// Set-up cDesgin
// Delete CSH function
MainColor = "#45ff88"


let rtroot = document.querySelector("html").style


rtroot.setProperty("--background-dk", "#050905")
rtroot.setProperty("--second-col-dk", "#010")
rtroot.setProperty("--opacit-col-dk", "#010b")
rtroot.setProperty("--text-color-dk", "#cec")

rtroot.setProperty("--background-wh", "#fff")
rtroot.setProperty("--second-col-wh", "#efe")
rtroot.setProperty("--opacit-col-wh", "#ded7")
rtroot.setProperty("--text-color-wh", "#020")